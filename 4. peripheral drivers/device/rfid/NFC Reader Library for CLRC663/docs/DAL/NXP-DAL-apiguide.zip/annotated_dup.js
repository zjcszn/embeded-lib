var annotated_dup =
[
    [ "phbalReg_Type_t", "d1/d6d/structphbalReg__Type__t.html", "d1/d6d/structphbalReg__Type__t" ],
    [ "phDriver_Pin_Config_t", "d9/da1/structphDriver__Pin__Config__t.html", "d9/da1/structphDriver__Pin__Config__t" ]
];