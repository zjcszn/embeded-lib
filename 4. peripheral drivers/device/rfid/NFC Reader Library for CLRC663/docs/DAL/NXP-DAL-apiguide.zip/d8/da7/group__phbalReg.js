var group__phbalReg =
[
    [ "phbalReg_Type_t", "d1/d6d/structphbalReg__Type__t.html", [
      [ "wId", "d1/d6d/structphbalReg__Type__t.html#a313cfd41cf4a4e77dc1f8c4ab7be2257", null ],
      [ "bBalType", "d1/d6d/structphbalReg__Type__t.html#a19dedc5b517bac403221e55f18529289", null ]
    ] ],
    [ "PHBAL_REG_CONFIG_WRITE_TIMEOUT_MS", "d8/da7/group__phbalReg.html#gaa2cc66f5750671f9986e98a7343d752c", null ],
    [ "PHBAL_REG_CONFIG_READ_TIMEOUT_MS", "d8/da7/group__phbalReg.html#gaf4f8bbcc492d939f039c013cca21d7e3", null ],
    [ "PHBAL_REG_TYPE_SPI", "d8/da7/group__phbalReg.html#gaa6bbfff4390edd43c650a971d7c2c29e", null ],
    [ "PHBAL_REG_TYPE_I2C", "d8/da7/group__phbalReg.html#gac0eba2414db200517ed3479970375077", null ],
    [ "PHBAL_REG_TYPE_SERIAL_WIN", "d8/da7/group__phbalReg.html#ga8b7a0c06189bc68a1a0228d1294b81a8", null ],
    [ "PHBAL_REG_TYPE_KERNEL_SPI", "d8/da7/group__phbalReg.html#ga5bef61a4c00e2fe063d806a0ae740a35", null ],
    [ "PHBAL_REG_TYPE_USER_SPI", "d8/da7/group__phbalReg.html#ga2f9c90bea92d94693618da3c1d24c85a", null ],
    [ "phbalReg_Init", "d8/da7/group__phbalReg.html#ga5d607982e12686283cbdd93d04daf992", null ],
    [ "phbalReg_Exchange", "d8/da7/group__phbalReg.html#ga4ca556c5a51648864635c7e315cc9f2c", null ],
    [ "phbalReg_SetConfig", "d8/da7/group__phbalReg.html#gac49cc5ff70179bd75aaa895aa49dce30", null ],
    [ "phbalReg_GetConfig", "d8/da7/group__phbalReg.html#ga59ed5aff3448cac9c28975f826d1d5b3", null ]
];