var structphDriver__Pin__Config__t =
[
    [ "bPullSelect", "d9/da1/structphDriver__Pin__Config__t.html#af24a584d41836491463f3b8671e232ae", null ],
    [ "bOutputLogic", "d9/da1/structphDriver__Pin__Config__t.html#a824868f85da04d394a45c59538d25c26", null ],
    [ "eInterruptConfig", "d9/da1/structphDriver__Pin__Config__t.html#aaf927b734a020dbab278de47ac761b8d", null ]
];