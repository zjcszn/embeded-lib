var annotated_dup =
[
    [ "phOsal_EventObj_t", "d5/da8/structphOsal__EventObj__t.html", null ],
    [ "phOsal_MutexObj_t", "db/dc8/structphOsal__MutexObj__t.html", null ],
    [ "phOsal_SemObj_t", "d6/d16/structphOsal__SemObj__t.html", null ],
    [ "phOsal_ThreadObj_t", "d2/d0d/structphOsal__ThreadObj__t.html", null ],
    [ "phOsal_TimerObj_t", "d3/d46/structphOsal__TimerObj__t.html", null ],
    [ "phOsal_TimerPeriodObj_t", "d6/dc3/structphOsal__TimerPeriodObj__t.html", null ]
];