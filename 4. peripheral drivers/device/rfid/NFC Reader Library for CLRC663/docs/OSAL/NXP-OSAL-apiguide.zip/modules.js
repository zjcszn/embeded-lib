var modules =
[
    [ "Operating System Abstraction Layer (OSAL)", "de/d3c/group__phOsal.html", "de/d3c/group__phOsal" ],
    [ "OSAL Config", "d9/d97/group__phOsal__Config.html", null ]
];