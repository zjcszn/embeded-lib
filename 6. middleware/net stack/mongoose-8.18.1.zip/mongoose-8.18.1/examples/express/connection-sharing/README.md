# Express Connection sharing Example

To run:

* Execute `npm install` from this directory
* Execute `node app.js`
* Navigate to `127.0.0.1:8000`
