This guide has moved to the [Mongoose docs site](https://mongoosejs.com/docs/migrating_to_5.html).
