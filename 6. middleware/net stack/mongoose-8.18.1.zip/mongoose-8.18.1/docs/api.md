# Redirecting

<script src="/docs/js/redirect-old-api.js"></script>

Redirecting to proper API page, please wait

<noscript>This Page requires JavaScript to Redirect old links properly</noscript>
