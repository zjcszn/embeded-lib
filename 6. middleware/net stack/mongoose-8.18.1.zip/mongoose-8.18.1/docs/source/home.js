'use strict';
const pkg = require('./../../package.json');

module.exports = {
  package: pkg,
  title: 'ODM'
};
