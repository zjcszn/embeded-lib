'use strict';
const { mapSubDoc } = require('./utils');

mapSubDoc('typescript', {
  title: 'Mongoose:',
  markdown: true
}, module.exports);
