<table>
    <tr>
        <td colspan="3"><center><b>Code Size of coreMQTT Agent (example generated with GCC for ARM Cortex-M)</b></center></td>
    </tr>
    <tr>
        <td><b>File</b></td>
        <td><b><center>With -O1 Optimization</center></b></td>
        <td><b><center>With -Os Optimization</center></b></td>
    </tr>
    <tr>
        <td>core_mqtt_agent.c</td>
        <td><center>1.7K</center></td>
        <td><center>1.5K</center></td>
    </tr>
    <tr>
        <td>core_mqtt_agent_command_functions.c</td>
        <td><center>0.3K</center></td>
        <td><center>0.2K</center></td>
    </tr>
    <tr>
        <td>core_mqtt.c (coreMQTT)</td>
        <td><center>4.0K</center></td>
        <td><center>3.4K</center></td>
    </tr>
    <tr>
        <td>core_mqtt_state.c (coreMQTT)</td>
        <td><center>1.7K</center></td>
        <td><center>1.3K</center></td>
    </tr>
    <tr>
        <td>core_mqtt_serializer.c (coreMQTT)</td>
        <td><center>2.8K</center></td>
        <td><center>2.2K</center></td>
    </tr>
    <tr>
        <td><b>Total estimates</b></td>
        <td><b><center>10.5K</center></b></td>
        <td><b><center>8.6K</center></b></td>
    </tr>
</table>
