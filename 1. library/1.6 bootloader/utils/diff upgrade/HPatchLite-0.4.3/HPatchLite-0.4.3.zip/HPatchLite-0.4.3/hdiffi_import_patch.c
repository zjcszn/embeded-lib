//hdiffi_import_patch.c
// import hpatchi cmd line to hdiffi
/*
 The MIT License (MIT)
 Copyright (c) 2020-2022 HouSisong All Rights Reserved.
 */
#include "hdiffi_import_patch.h"
#define _IS_NEED_MAIN 0
#include "hpatchi.c"