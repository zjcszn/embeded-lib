// hpatchi.c
// Created by sisong on 2022-08-19.
#include "hpatchi.h"

#ifndef _IS_USED_MULTITHREAD
#define _IS_USED_MULTITHREAD            0
#endif
#define _IS_NEED_MAIN                   0
#define _IS_NEED_ALL_CompressPlugin     0
#define _IS_NEED_PRINT_LOG              0

#include "../../hpatchi.c"
