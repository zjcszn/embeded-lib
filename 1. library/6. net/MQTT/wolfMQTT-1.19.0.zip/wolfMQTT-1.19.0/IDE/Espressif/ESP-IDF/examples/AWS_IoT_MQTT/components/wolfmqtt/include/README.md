# wolfMQTT README

This directory exists to appease the ESP-IDF component manager.

The wolfSSL `user_settings.h` does NOT belong in this directory.

For details on wolfMQTT [see the wolfMQTT Manual](https://www.wolfssl.com/documentation/manuals/wolfmqtt/wolfMQTT-Manual.pdf).
