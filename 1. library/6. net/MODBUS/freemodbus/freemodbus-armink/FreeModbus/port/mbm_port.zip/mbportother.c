/* ----------------------- System includes ----------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

#include "mbport.h"
#include "all_modules_include.h"

/* ----------------------- Platform includes --------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"

/* ----------------------- Modbus includes ----------------------------------*/
#include "common/mbtypes.h"
#include "mbportlayer.h"
#include "common/mbframe.h"
#include "common/mbutils.h"

#include "generic/type_include.h"

#undef DEBUG_PRINT_MODULE
#define DEBUG_PRINT_MODULE DEBUG_PRINT_MODULE__MODBUS_TASK

/* ----------------------- Defines ------------------------------------------*/
#define MBM_LOGFACILITIES                       ( 0xFFFFU )
#define MBM_LOGLEVELS                           ( MB_LOG_ERROR )

/* ----------------------- Type definitions ---------------------------------*/

/* ----------------------- Static variables ---------------------------------*/
#if ( ( defined( MBP_ENABLE_DEBUG_FACILITY ) && ( MBP_ENABLE_DEBUG_FACILITY == 1 ) ) || ( defined( MBM_ENABLE_DEBUG_FACILITY ) && ( MBM_ENABLE_DEBUG_FACILITY == 1 ) ) )
STATIC CHAR arubDebugBuffer[256];

SemaphoreHandle_t xDebugBufferLock;
#endif
/* ----------------------- Static functions ---------------------------------*/

/* ----------------------- Start implementation -----------------------------*/
#if ( ( defined( MBP_ENABLE_DEBUG_FACILITY ) && ( MBP_ENABLE_DEBUG_FACILITY == 1 ) ) || ( defined( MBM_ENABLE_DEBUG_FACILITY ) && ( MBM_ENABLE_DEBUG_FACILITY == 1 ) ) )

const CHAR *
pszMBPModule2String(eMBPortLogFacility eModule) {
	const CHAR *pszRetValue;

	switch (eModule) {
	case MB_LOG_CORE:
		pszRetValue = "CORE";
		break;
	case MB_LOG_RTU:
		pszRetValue = "RTU";
		break;
	case MB_LOG_ASCII:
		pszRetValue = "ASCII";
		break;
	case MB_LOG_TCP:
		pszRetValue = "TCP";
		break;
	case MB_LOG_PORT_EVENT:
		pszRetValue = "EVENT";
		break;
	case MB_LOG_PORT_TIMER:
		pszRetValue = "TIMER";
		break;
	case MB_LOG_PORT_SERIAL:
		pszRetValue = "SERIAL";
		break;
	case MB_LOG_PORT_TCP:
		pszRetValue = "TCP";
		break;
	case MB_LOG_PORT_OTHER:
		pszRetValue = "OTHER";
		break;
	default:
		pszRetValue = "UNKNOWN";
		break;
	}
	return pszRetValue;
}

void vMBPPortLog(eMBPortLogFacility eModule, const CHAR * szFmt, ...) {
	int i = 0, j = 0, max_len;

	va_list args;

	max_len = sizeof(arubDebugBuffer) / sizeof(arubDebugBuffer[0]);
	j = snprintf(&arubDebugBuffer[i], max_len, "%s;", pszMBPModule2String(eModule));
	if ((j > 0) || (j <= max_len)) {
		max_len -= j;
		i += j;
	}

	va_start(args, szFmt);
	j = vsnprintf(&arubDebugBuffer[i], max_len, szFmt, args);
	va_end(args);

	DbgPrint(arubDebugBuffer);

}
#endif

SemaphoreHandle_t MBPmutex = NULL;

void vMBPEnterCritical(void)
{
	//DbgPrint("take-in");
	if (taskSCHEDULER_RUNNING == xTaskGetSchedulerState())
	{
		if (IsPtrValid((void *)MBPmutex))
		{
			xSemaphoreTakeRecursive(MBPmutex, 2);
		}
	}
	//DbgPrint("take-out");
	//portENTER_CRITICAL( );
}

void vMBPExitCritical(void)
{
	//DbgPrint("give-in");
	if (taskSCHEDULER_RUNNING == xTaskGetSchedulerState())
	{
		if (IsPtrValid((void *)MBPmutex))
		{
			xSemaphoreGiveRecursive(MBPmutex);
		}
	}
	//DbgPrint("give-out");
	//portEXIT_CRITICAL( );
}

void vMBPEnterCriticalInit(void)
{
	DbgPrint("MBP CRITICAL INIT");

	if (IsPtrValid((void *)MBPmutex) == FALSE)
	{
		//MBPmutex = xSemaphoreCreateMutex();
		MBPmutex = xSemaphoreCreateRecursiveMutex();
		vMBPExitCritical();
	}
}

void vMBPExitCriticalInit(void)
{
	DbgPrint("MBP CRITICAL DEINIT");
	;
}

void vMBPLibraryLoad(void)
{
	DbgPrint("MBP LIBRARY LOAD");
}

void vMBPLibraryUnload(void)
{
	DbgPrint("MBP LIBRARY UNLOAD");
}
