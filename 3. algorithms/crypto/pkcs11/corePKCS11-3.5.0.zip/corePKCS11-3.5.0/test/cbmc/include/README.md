CBMC proof include files
========================

This directory contains include files written for CBMC proof.  It is
common to write some code to model aspects of the system under test,
and the header files for this code go here.
